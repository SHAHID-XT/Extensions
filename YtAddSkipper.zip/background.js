const CONFIGURE_CHANNEL = "CONFIGURE_CHANNEL";
const GO_PREF_HOME = "GO_PREF_HOME";
const VERIFY_SUBSCRIPTION = "VERIFY_SUBSCRIPTION";

function debug(...args) {
    return void 0;
}
function error(...args) {
    return console.error("[yt-ad-skipper:error]", ...args);
}
function warn(...args) {
    return console.warn("[yt-ad-skipper:warn]", ...args);
}
const logger = { debug, error, warn };

/******************************************************************************
Copyright (c) Microsoft Corporation.

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
PERFORMANCE OF THIS SOFTWARE.
***************************************************************************** */

function __awaiter(thisArg, _arguments, P, generator) {
  function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
  return new (P || (P = Promise))(function (resolve, reject) {
      function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
      function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
      function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
      step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
}

typeof SuppressedError === "function" ? SuppressedError : function (error, suppressed, message) {
  var e = new Error(message);
  return e.name = "SuppressedError", e.error = error, e.suppressed = suppressed, e;
};

const BASE_URL = "https://ad-auto-skipper.web.app"
    ;
function fetchSubscriptionForUser(token) {
    return __awaiter(this, void 0, void 0, function* () {
        const res = yield fetch(`${BASE_URL}/fns/v1/fetch_subscription_checkout`, {
            headers: {
                token,
            },
        }).then((res) => res.json());
        if ("checkoutUrl" in res) {
            return {
                checkoutUrl: res.checkoutUrl,
                sessionId: res.sessionId,
            };
        }
        return res;
    });
}
function fetchSubscriptionForSession(sessionId) {
    var _a;
    return __awaiter(this, void 0, void 0, function* () {
        const res = yield fetch(`${BASE_URL}/fns/v1/fetch_subscription_by_session/${sessionId}`).then((res) => res.json());
        if ("subscribed" in res) {
            return res;
        }
        logger.error(res.error);
        throw new Error((_a = res.error) === null || _a === void 0 ? void 0 : _a.message);
    });
}
function isSubscriptionActive(subscriptionId) {
    return __awaiter(this, void 0, void 0, function* () {
        const res = yield fetch(`${BASE_URL}/fns/v1/fetch_subscription/${subscriptionId}`).then((res) => res.json());
        if ("subscribed" in res && res.subscribed) {
            return true;
        }
        return false;
    });
}
function cancelSubscription(token) {
    return __awaiter(this, void 0, void 0, function* () {
        const res = yield fetch(`${BASE_URL}/fns/v1/cancel_subscription`, {
            method: "POST",
            headers: {
                token,
            },
        }).then((res) => res.json());
        return res;
    });
}

function storeSubscription(sub, user) {
    const subscription = Object.assign(Object.assign({}, sub), { user, nextSyncAt: Date.now() + 24 * 60 * 60 * 1000 });
    return chrome.storage.local.set({
        subscription,
    });
}
function configureChannel({ channelId, channelName, imageUrl, }) {
    chrome.storage.local
        .set({
        page: `channel`,
        pageProps: {
            channelId,
            channelName,
            imageUrl,
        },
    })
        .then(() => {
        chrome.runtime.openOptionsPage();
    });
}
function goPrefHome() {
    chrome.storage.local
        .set({
        page: `pref`,
        pageProps: {},
    })
        .then(() => {
        return chrome.runtime.openOptionsPage();
    });
}
function loginSuccess(user, tab) {
    return __awaiter(this, void 0, void 0, function* () {
        const url = (() => {
            try {
                return new URL(tab.url || "");
            }
            catch (_a) {
                return null;
            }
        })();
        if (url === null || url === void 0 ? void 0 : url.href.includes("cancel=1")) {
            const res = yield cancelSubscription(user.stsTokenManager.accessToken);
            if (res.success) {
                yield chrome.storage.local.remove("subscription");
                chrome.runtime.openOptionsPage();
                yield chrome.tabs.remove(tab.id);
            }
            return;
        }
        const res = yield fetchSubscriptionForUser(user.stsTokenManager.accessToken);
        if ("subscribed" in res && res.subscribed) {
            yield storeSubscription(res, user);
            chrome.runtime.openOptionsPage();
            yield chrome.tabs.remove(tab.id);
            return;
        }
        if ("checkoutUrl" in res && res.checkoutUrl) {
            const checkoutSession = {
                expireAt: Date.now() + 24 * 60 * 60 * 1000,
                sessionId: res.sessionId,
                user: user,
            };
            yield chrome.storage.local.set({
                checkoutSession,
            });
            yield chrome.tabs.update(tab.id, {
                url: res.checkoutUrl,
            });
            return;
        }
        chrome.runtime.openOptionsPage();
        yield chrome.tabs.remove(tab.id);
    });
}
function completeCheckout(success, tab) {
    return __awaiter(this, void 0, void 0, function* () {
        if (!success) {
            chrome.runtime.openOptionsPage();
            yield chrome.tabs.remove(tab.id);
            return;
        }
        try {
            const checkoutSession = yield chrome.storage.local
                .get(["checkoutSession"])
                .then((data) => data.checkoutSession);
            if (!checkoutSession || checkoutSession.expireAt < Date.now()) {
                throw new Error();
            }
            const sub = yield fetchSubscriptionForSession(checkoutSession.sessionId);
            if (sub.subscribed) {
                yield storeSubscription(sub, checkoutSession.user);
                yield chrome.storage.local.remove(["checkoutSession"]);
            }
        }
        catch (err) {
            logger.error(err);
        }
        chrome.runtime.openOptionsPage();
        yield chrome.tabs.remove(tab.id);
    });
}
function verifySubscription() {
    return __awaiter(this, void 0, void 0, function* () {
        const subscription = yield chrome.storage.local
            .get(["subscription"])
            .then((v) => v.subscription);
        if (!subscription) {
            return;
        }
        const { subscriptionId, nextSyncAt } = subscription;
        if (nextSyncAt > Date.now()) {
            return;
        }
        if (yield isSubscriptionActive(subscriptionId)) {
            yield storeSubscription(subscription, subscription.user);
            return;
        }
        yield chrome.storage.local.remove("subscription");
    });
}

chrome.runtime.onMessage.addListener((message) => {
    if (!("type" in message)) {
        return;
    }
    switch (message.type) {
        case CONFIGURE_CHANNEL:
            configureChannel(message.channel);
            break;
        case GO_PREF_HOME:
            goPrefHome();
            break;
        case VERIFY_SUBSCRIPTION:
            verifySubscription();
            break;
    }
});
chrome.runtime.onMessageExternal.addListener((message, sender) => {
    if (!("type" in message)) {
        return;
    }
    logger.debug("Message from: ", sender.tab);
    switch (message.type) {
        case "LOGIN_SUCCESS": {
            loginSuccess(message.user, sender.tab);
            break;
        }
        case "COMPLETE_CHECKOUT":
            completeCheckout(message.success, sender.tab);
            break;
    }
});
chrome.runtime.onInstalled.addListener((details) => {
    if (details.reason === "install") {
        chrome.runtime.openOptionsPage();
        return;
    }
    if (details.reason === "update") {
        chrome.storage.local.get(["subscription"]).then(({ subscription }) => {
        });
    }
});
chrome.action.onClicked.addListener(() => {
    chrome.runtime.openOptionsPage();
});
