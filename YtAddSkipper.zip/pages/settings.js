/******************************************************************************
Copyright (c) Microsoft Corporation.

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
PERFORMANCE OF THIS SOFTWARE.
***************************************************************************** */

function __awaiter(thisArg, _arguments, P, generator) {
  function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
  return new (P || (P = Promise))(function (resolve, reject) {
      function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
      function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
      function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
      step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
}

typeof SuppressedError === "function" ? SuppressedError : function (error, suppressed, message) {
  var e = new Error(message);
  return e.name = "SuppressedError", e.error = error, e.suppressed = suppressed, e;
};

const CONFIGURE_CHANNEL = "CONFIGURE_CHANNEL";
const GO_PREF_HOME = "GO_PREF_HOME";

function isObject(o) {
    return typeof o === "object" && o !== null;
}
function deepmerge(...objs) {
    let newObj = {};
    for (const obj of objs) {
        if (!isObject(obj))
            continue;
        for (const [key, val] of Object.entries(obj)) {
            if (isObject(val) && key in newObj) {
                newObj = Object.assign(Object.assign({}, newObj), { [key]: deepmerge(val, newObj[key]) });
            }
            else {
                newObj = Object.assign(Object.assign({}, newObj), { [key]: val });
            }
        }
    }
    return newObj;
}

function debug(...args) {
    return void 0;
}
function error(...args) {
    return console.error("[yt-ad-skipper:error]", ...args);
}
function warn(...args) {
    return console.warn("[yt-ad-skipper:warn]", ...args);
}
const logger = { debug, error, warn };

const AD_PLAYBACK_OFFSET = 5;
const DEFAULT_CONFIG = Object.freeze({
    globalConfig: {
        timeToSkip: AD_PLAYBACK_OFFSET,
        muteAd: false,
    },
    channelConfigs: {},
});
function getSubscription() {
    return __awaiter(this, void 0, void 0, function* () {
        const { subscription } = yield chrome.storage.local.get(["subscription"]);
        return subscription;
    });
}
function getConfig() {
    return __awaiter(this, void 0, void 0, function* () {
        const { config, subscription } = yield chrome.storage.local.get([
            "config",
            "subscription",
        ]);
        if (!config || !(subscription === null || subscription === void 0 ? void 0 : subscription.subscriptionId)) {
            return DEFAULT_CONFIG;
        }
        return config;
    });
}
function setConfig(config) {
    return __awaiter(this, void 0, void 0, function* () {
        const subscription = yield getSubscription();
        if (!(subscription === null || subscription === void 0 ? void 0 : subscription.subscriptionId)) {
            return;
        }
        return yield chrome.storage.local.set({ config });
    });
}
function mergeChannelConfig(scope, addition) {
    return __awaiter(this, void 0, void 0, function* () {
        const currentConfig = yield getConfig();
        if (scope === "global") {
            const newConfig = Object.assign(Object.assign({}, currentConfig), { globalConfig: deepmerge(currentConfig.globalConfig, addition) });
            yield setConfig(newConfig);
            return;
        }
        if (!(scope in currentConfig.channelConfigs)) {
            logger.warn("Channel has not been created yet. This should not happen.");
            return;
        }
        const newConfig = Object.assign(Object.assign({}, currentConfig), { channelConfigs: Object.assign(Object.assign({}, currentConfig.channelConfigs), { [scope]: deepmerge(currentConfig.channelConfigs[scope], addition) }) });
        yield setConfig(newConfig);
    });
}
function getTimeToSkipAdOffset(channelId) {
    return __awaiter(this, void 0, void 0, function* () {
        const config = yield getConfig();
        if (channelId && channelId in config.channelConfigs) {
            return config.channelConfigs[channelId].timeToSkip;
        }
        return config.globalConfig.timeToSkip;
    });
}
function setTimeToSkipAdOffset(scope, value) {
    return __awaiter(this, void 0, void 0, function* () {
        const configAddition = {
            timeToSkip: value,
        };
        yield mergeChannelConfig(scope, configAddition);
        return yield getTimeToSkipAdOffset();
    });
}
function getShouldMuteAd(channelId) {
    return __awaiter(this, void 0, void 0, function* () {
        const config = yield getConfig();
        if (channelId && channelId in config.channelConfigs) {
            return config.channelConfigs[channelId].muteAd;
        }
        return config.globalConfig.muteAd;
    });
}
function setShouldMuteAd(scope, value) {
    return __awaiter(this, void 0, void 0, function* () {
        const configAddition = {
            muteAd: value,
        };
        yield mergeChannelConfig(scope, configAddition);
        return getShouldMuteAd();
    });
}
function getChannelConfig(channelId) {
    return __awaiter(this, void 0, void 0, function* () {
        const currentConfig = yield getConfig();
        if (channelId === "global") {
            return currentConfig.globalConfig;
        }
        return currentConfig.channelConfigs[channelId];
    });
}
function createChannel(channelId, channelName, imageUrl) {
    return __awaiter(this, void 0, void 0, function* () {
        const currentConfig = yield getConfig();
        const newConfig = Object.assign(Object.assign({}, currentConfig), { channelConfigs: Object.assign(Object.assign({}, currentConfig.channelConfigs), { [channelId]: {
                    channelId,
                    channelName,
                    imageUrl,
                    timeToSkip: DEFAULT_CONFIG.globalConfig.timeToSkip,
                    muteAd: DEFAULT_CONFIG.globalConfig.muteAd,
                } }) });
        yield setConfig(newConfig);
    });
}
function removeChannel(channelId) {
    return __awaiter(this, void 0, void 0, function* () {
        const currentConfig = yield getConfig();
        const newChannelConfig = Object.fromEntries(Object.entries(currentConfig.channelConfigs).filter(([id]) => id !== channelId));
        const newConfig = Object.assign(Object.assign({}, currentConfig), { channelConfigs: newChannelConfig });
        yield setConfig(newConfig);
    });
}

const CSS$2 = `
.pref-box, ul {
  margin-bottom: 1em;
  border-radius: 1em;
  background-color: var(--pref-box-bg);
  border: none;
  padding: 0;
  display: flex;
  flex-direction: column;
  overflow: hidden;
}

.empty-channel-list {
  padding-top: 1em;
}

.empty-channel-list p {
  margin: 0 1.5em 1em;
  padding: 0;
}

.channel-row img {
  height: 2em;
  border-radius: 1em;
}

.channel-row:hover .remove-channel-btn {
  display: block;
}

.channel-row .remove-channel-btn {
  display: none;
  background: inherit;
  border: none;
  height: 2em;
  width: 2em;
  color: white;
  background-color: indianred;
  border-radius: 1em;
}

.pref-row {
  padding: 1em 1.5em;
  border-bottom: 1px solid var(--bg-color);
  display: flex;
  align-items: center;
  cursor: pointer;
  box-sizing: border-box;
  gap: 1em;
}

.pref-row .label {
  flex: 1;
  color: inherit;
  text-decoration: none;
}`;
const TEMPLATE$2 = `
<slot name="empty-list">
  <div class="pref-box empty-channel-list">
    <p>You have not configured any channels yet!</p>
    <p>
      Find Ad Skipper besides the Subscribe button when watching a YouTube
      video. Click on it to configure the extension for that channel.
    </p>
    <img
      src="./preview.png"
      alt="Pointing out Ad Skipper button besides Subscribe button in YouTube."
    />
  </div>
</slot>
`;
class AdsChannelList extends HTMLElement {
    get state() {
        return this._state;
    }
    set state(newState) {
        this._state = deepmerge(this._state, newState);
        this.render();
    }
    constructor() {
        super();
        this._state = {
            channels: [],
        };
        this.render = () => {
            var _a;
            if (!this.shadowRoot)
                return;
            this.innerHTML = "";
            const ul = this.shadowRoot.querySelector("ul") || document.createElement("ul");
            if (!((_a = this.state.channels) === null || _a === void 0 ? void 0 : _a.length)) {
                return;
            }
            ul && (ul.innerHTML = "");
            for (const channel of this.state.channels) {
                const li = document.createElement("li");
                li.className = "pref-row channel-row";
                li.onclick = () => {
                    chrome.runtime.sendMessage({
                        type: CONFIGURE_CHANNEL,
                        channel: channel,
                    });
                };
                li.innerHTML = `
        <img src=${channel.imageUrl} alt="" />
        <span class="label">
          ${channel.channelName}
        </span>
      `;
                const btn = document.createElement("button");
                btn.className = "remove-channel-btn";
                btn.setAttribute("role", "button");
                btn.title = "Remove channel configuration";
                btn.textContent = "x";
                btn.onclick = (e) => {
                    e.stopPropagation();
                    removeChannel(channel.channelId);
                };
                li.append(btn);
                ul === null || ul === void 0 ? void 0 : ul.append(li);
            }
            ul.parentElement || this.shadowRoot.prepend(ul);
            this.innerHTML = `<slot slot="empty-list"></slot>`;
        };
        const style = document.createElement("style");
        style.textContent = CSS$2;
        const body = document.createElement("template");
        body.innerHTML = TEMPLATE$2;
        const root = this.attachShadow({ mode: "open" });
        root.append(style, body.content);
    }
    connectedCallback() {
        const syncChannels = () => {
            getConfig().then((config) => {
                this._state = {
                    channels: Object.values(config.channelConfigs).sort((a, b) => a.channelName.localeCompare(b.channelName)),
                };
                this.render();
            });
        };
        syncChannels();
        chrome.storage.onChanged.addListener((changes) => {
            if ("config" in changes) {
                syncChannels();
            }
        });
    }
}
AdsChannelList.elementName = "ads-channel-list";
customElements.define(AdsChannelList.elementName, AdsChannelList);

const BASE_URL = "https://ad-auto-skipper.web.app"
    ;
const AUTH_PAGE = `${BASE_URL}/login.html`;
const API = {
    SIGNUP: `${AUTH_PAGE}?signup=1`,
    ACTIVATE: AUTH_PAGE,
    CANCEL: `${AUTH_PAGE}?cancel=1`,
};

const CSS$1 = `
.pref-box {
  margin-bottom: 1em;
  border-radius: 1em;
  background-color: var(--pref-box-bg);
  border: none;
  padding: 0;
  display: flex;
  flex-direction: column;
  overflow: hidden;
}

.pref-box .pref-row {
  padding: 1em 1.5em;
  border-bottom: 1px solid var(--bg-color);
  display: flex;
  align-items: center;
  cursor: pointer;
  box-sizing: border-box;
  gap: 1em;
}

.pref-box .pref-row:last-child {
  border-bottom: none;
}

.pref-box .pref-row input {
  width: 2.5em;
  text-align: right;
}

.pref-box .pref-row input[type="checkbox"] {
  height: 1.5em;
}

.pref-box .pref-row .label {
  flex: 1;
  color: inherit;
  text-decoration: none;
}

.pref-desc {
  margin: 0;
  margin-top: 0.5em;
  font-size: 0.8em;
  opacity: 0.5;
  text-transform: none;
}`;
const TEMPLATE$1 = `
<form>
  <fieldset class="pref-box">
    <label class="pref-row">
      <div class="label">
        <span>Mute Ads</span>
        <p class="pref-desc">Ads will be muted when they start playing.</p>
      </div>
      <input type="checkbox" name="mutead" />
    </label>
    <label class="pref-row">
      <div class="label">
        <span>Seconds to play ad before skipping</span>
        <p class="pref-desc">
          Ads will play for the supplied number of seconds before they are
          skiped. The default value is 5 seconds as that is when YouTube
          makes the "Skip Ad" button visible, but the value can be as low as
          0, where you won't see any ads.
        </p>
      </div>
      <input type="number" name="skipsecs" />
    </label>
  </fieldset>
</form>`;
class AdsChannelPrefForm extends HTMLElement {
    constructor() {
        super();
        this._state = {
            isMute: false,
            skipSecs: 0,
        };
        this.props = {
            channelId: "",
            channelName: "",
            imageUrl: "",
            isDisabled: false,
        };
        this.shouldCreateChannel = false;
        this.render = () => {
            if (!this.shadowRoot)
                return;
            const toggleMuteInput = this.shadowRoot.querySelector("input[name=mutead]");
            if (toggleMuteInput) {
                toggleMuteInput.onchange = this.toggleIsMute;
                this.props.isDisabled && toggleMuteInput.setAttribute("disabled", "");
                this.state.isMute && toggleMuteInput.setAttribute("checked", "");
            }
            const skipSecsInput = this.shadowRoot.querySelector("input[name=skipsecs]");
            if (skipSecsInput) {
                skipSecsInput.setAttribute("value", "" + this.state.skipSecs);
                skipSecsInput.onchange = this.updateSkipSecs;
                this.props.isDisabled && skipSecsInput.setAttribute("disabled", "");
            }
        };
        this.createChannelIfRequired = () => __awaiter(this, void 0, void 0, function* () {
            if (this.shouldCreateChannel &&
                this.props.channelId &&
                this.props.channelName &&
                this.props.imageUrl) {
                yield createChannel(this.props.channelId, this.props.channelName, this.props.imageUrl);
            }
        });
        this.updateSkipSecs = (e) => {
            const input = e.target;
            const val = +input.value;
            if (isNaN(val)) {
                input.value = "" + this.state.skipSecs;
                return;
            }
            input.value = "" + val;
            this.createChannelIfRequired()
                .then(() => setTimeToSkipAdOffset(this.props.channelId || "global", val))
                .catch(() => {
                getTimeToSkipAdOffset().then((newVal) => {
                    this.state = {
                        skipSecs: newVal,
                    };
                });
            });
        };
        this.toggleIsMute = () => {
            this.createChannelIfRequired()
                .then(() => setShouldMuteAd(this.props.channelId || "global", !this.state.isMute))
                .catch(() => {
                getShouldMuteAd().then((newVal) => {
                    this.state = {
                        isMute: newVal,
                    };
                });
            });
        };
        const style = document.createElement("style");
        style.textContent = CSS$1;
        const body = document.createElement("template");
        body.innerHTML = TEMPLATE$1;
        const root = this.attachShadow({ mode: "open" });
        root.append(style, body.content);
    }
    connectedCallback() {
        var _a, _b, _c;
        this.props = {
            channelId: (_a = this.getAttribute("channel-id")) !== null && _a !== void 0 ? _a : "",
            channelName: (_b = this.getAttribute("channel-name")) !== null && _b !== void 0 ? _b : "",
            imageUrl: (_c = this.getAttribute("image-url")) !== null && _c !== void 0 ? _c : "",
            isDisabled: this.hasAttribute("is-disabled"),
        };
        getChannelConfig(this.props.channelId || "global")
            .then((config) => {
            if (!config) {
                this.shouldCreateChannel = true;
                this._state = {
                    skipSecs: DEFAULT_CONFIG.globalConfig.timeToSkip,
                    isMute: DEFAULT_CONFIG.globalConfig.muteAd,
                };
                return;
            }
            this._state = {
                skipSecs: config.timeToSkip,
                isMute: config.muteAd,
            };
        })
            .then(() => this.render());
    }
    get state() {
        return this._state;
    }
    set state(newState) {
        this._state = deepmerge(this._state, newState);
        this.render();
    }
}
AdsChannelPrefForm.elementName = "ads-channel-pref-form";
customElements.define(AdsChannelPrefForm.elementName, AdsChannelPrefForm);

const CSS = `
.channel-pref-header {
  margin-bottom: 1em;
  border-radius: 1em;
  background-color: var(--pref-box-bg);
  padding: 1em;
  display: flex;
  align-items: center;
  text-align: center;
}

.back-btn {
  border: none;
  color: inherit;
  border-radius: 50%;
  background: rgba(255,255,255, 0.1);
  width: 3em;
  aspect-ratio: 1;
  font-family: monospace;
  cursor: pointer;
}

.channel-logo {
  width: 3em;
  aspect-ratio: 1;
  border-radius: 1.5em;
  overflow: hidden;
}

.channel-pref-title {
  flex: 1;
}`;
const TEMPLATE = `
<div class="channel-pref-header">
  <button role="button" class="back-btn">&lt;</button>
  <h2 class="channel-pref-title">
    <slot name="channel-pref-title"></slot>
  </h2>
  <div class="channel-logo">
    <slot name="channel-logo"></slot>
  </div>
</div>
<slot name="channel-pref-form"></slot>
`;
class AdsChannelPref extends HTMLElement {
    constructor() {
        super();
        this.render = () => {
            var _a, _b, _c, _d;
            if (!this.shadowRoot)
                return;
            const [channelId, channelName, imageUrl] = [
                (_a = this.getAttribute("channel-id")) !== null && _a !== void 0 ? _a : "",
                (_b = this.getAttribute("channel-name")) !== null && _b !== void 0 ? _b : "",
                (_c = this.getAttribute("image-url")) !== null && _c !== void 0 ? _c : "",
            ];
            (_d = this.shadowRoot.querySelector("button")) === null || _d === void 0 ? void 0 : _d.addEventListener("click", () => {
                chrome.runtime.sendMessage({
                    type: GO_PREF_HOME,
                });
            });
            this.innerHTML = `
      <slot slot="channel-pref-title">${channelName}</slot>
      <img slot="channel-logo" src="${imageUrl}" alt="" />
      <${AdsChannelPrefForm.elementName}
        slot="channel-pref-form"
        channel-id="${channelId}"
        channel-name="${channelName}"
        image-url="${imageUrl}"
      />
    `;
        };
        const style = document.createElement("style");
        style.textContent = CSS;
        const body = document.createElement("template");
        body.innerHTML = TEMPLATE;
        const root = this.attachShadow({ mode: "open" });
        root.append(style, body.content);
    }
    connectedCallback() {
        this.render();
    }
}
AdsChannelPref.elementName = "ads-channel-pref";
customElements.define(AdsChannelPref.elementName, AdsChannelPref);

const css$1 = `
a:link,
a:visited {
  color: inherit;
}

a:hover {
  text-decoration: none;
}

.license {
  border-radius: 1em;
  background-color: var(--pref-box-bg);
  border: none;
  display: flex;
  flex-direction: column;
  overflow: hidden;
  padding: 1em 1.5em;
  margin-bottom: 3em;
}

.license p {
  line-height: 1.3em;
  margin-bottom: 1em;
  margin-top: 0.25em;
}

.license-btns {
  display: flex;
  flex-direction: column;
  text-align: center;
}

.license-btns .btn {
  flex: 1;
  padding: 1em;
  background: rgba(0,0,0,0.1);
  border-radius: 1em;
  border: none;
  color: inherit;
  font-size: 1em;
  display: block;
  text-decoration: none;
  text-align: center;
}

.license-btns .btn:hover {
  text-decoration: underline;
}

.license-btns .btn-primary {
  background: darkslateblue;
  color: white;
}

.license-btns p {
  opacity: 0.8;
}

p.license-highlight {
  font-weight: bold;
  margin-bottom: 2em;
}

.license-highlight span {
  border-bottom: solid 0.7em orange;
  text-transform: uppercase;
}

ul {
  margin: 0;
}
`;
const template$1 = `
<section class="license">
  <h1>
    <slot name="greeting">
      Hi 👋
    </slot>
  </h1>
  <slot name="message">
    <p>
      I am a software developer from Nepal, currently living in Toronto.
    </p>
    <p>
      I created YouTube Ad Auto-skipper in 2018 to make my life easier. I
      have been maintaining it during my weekends and evenings while
      juggling a job, school and family. I plan to focus on developing much
      requested functionalities in the near future.
    </p>
    <p>
      I only request 3 cups of coffee ☕️ per year to support the
      development of this extension.
    </p>
    <p>Your support will unlock features such as:
      <ul>
        <li>muting ads</li>
        <li>button to end countdown if you want ad to continue playing</li>
        <li>configuring ad playback length before it is skipped</li>
        <li>custom configuration per YouTube channel</li>
      </ul>
    </p>
    <p class="license-highlight">
      The original functionality of automatically skipping ads is and
      will <span>always remain FREE!</span>
    </p>
    <div class="license-btns">
      <a class="btn btn-primary" href="${API.SIGNUP}">
        Unlock additional features for $7 per year
      </a>
      <p>
        Are you already a supporter?
        <a href="${API.ACTIVATE}">Click here to unlock all features.</a>
      </p>
    </div>
  </slot>
</section>`;
class AdsLicense extends HTMLElement {
    constructor() {
        super();
        const style = document.createElement("style");
        style.textContent = css$1;
        const body = document.createElement("template");
        body.innerHTML = template$1;
        const root = this.attachShadow({ mode: "open" });
        root.append(style, body.content);
    }
    connectedCallback() {
        this.render();
    }
    render() {
        const user = this.getAttribute("user");
        if (user) {
            this.innerHTML = `
        <slot slot="greeting">Hi ${user.split(" ")[0]} 👋</slot>
        <slot slot="message"></slot>
      `;
        }
    }
}
AdsLicense.elementName = "ads-license";
customElements.define(AdsLicense.elementName, AdsLicense);

const css = `
a:link,
a:visited {
  color: inherit;
}

.container {
  margin: 2em auto;
  max-width: 32em;
  opacity: 1;
  animation: animate-in 0.1s ease-in;
}

@keyframes animate-in {
  0% {
    opacity: 0;
  }
  100% {
    opacity: 1
  }
}

.container h1, .container h2 {
  font-weight: normal;
  padding: 0 1.5rem;
}

h2.title {
  font-size: 0.9em;
  opacity: 0.8;
  flex: 1;
  text-transform: uppercase;
}

p {
  margin: 0;
  margin-top: 0.5em;
  font-size: 0.8em;
  opacity: 0.5;
  text-transform: none;
}
.pref-disabled {
  opacity: 0.5;
  pointer-events: none;
}

.license-footer {
  opacity: 0.5;
  font-size: 0.9em;
  text-align: center;
}
`;
const template = `
<div class="container">
  <h1>Youtube Ad Auto-skipper</h1>
  <slot name="config">
    <slot name="license">
      <${AdsLicense.elementName} />
    </slot>
    <div class="can-disable">
      <h2 class="title">
        Global Preferences
        <p>
          These preferences will be used for all videos unless there is a
          specific configuration for a YouTube channel defined below.
        </p>
      </h2>
      <${AdsChannelPrefForm.elementName} />
    </div>
    <div class="can-disable">
      <h2 class="title">
        Channel Preferences
        <p>
          You can configure Ad-Skipper to have a different behavior in videos
          by your favourite YouTubers.
        </p>
        <p>
          Did you know? YouTubers are paid 50% of the revenue from ads playing
          on their videos. You can support your favorite YouTubers by letting
          ads play longer on their channel.
        </p>
      </h2>
      <${AdsChannelList.elementName} />
    </div>
    <slot name="license-footer">
      <div class="license-footer">
        <p>
          You support the development of this extension with an annual payment.
          <br>
          <a href="${API.CANCEL}">Click here to cancel future payments.</a>
        </p>
      </div>
    </slot>
  </slot>
</div>`;
class AdsSettings extends HTMLElement {
    constructor() {
        super();
        this._state = {
            user: null,
            page: "pref",
            pageProps: {},
        };
        this.render = () => {
            var _a;
            const user = this.state.user;
            this.innerHTML = "";
            if (this.state.page === "channel" && user) {
                const { channelId, channelName, imageUrl } = this.state.pageProps;
                const slot = document.createElement("slot");
                slot.slot = "config";
                const channelConfig = document.createElement(AdsChannelPref.elementName);
                channelConfig.setAttribute("channel-id", channelId);
                channelConfig.setAttribute("channel-name", channelName);
                channelConfig.setAttribute("image-url", imageUrl);
                slot.append(channelConfig);
                this.append(slot);
                return;
            }
            if (user) {
                const license = document.createElement(AdsLicense.elementName);
                license.slot = "license";
                license.setAttribute("user", user === null || user === void 0 ? void 0 : user.displayName);
                this.append(license);
            }
            if (!user) {
                Array.from(((_a = this.shadowRoot) === null || _a === void 0 ? void 0 : _a.querySelectorAll(".can-disable")) || []).forEach((elem) => {
                    elem.className = "pref-disabled";
                });
                const slot = document.createElement("slot");
                slot.slot = "license-footer";
                this.append(slot);
            }
        };
        this.getUserFromStorage = () => __awaiter(this, void 0, void 0, function* () {
            const subscription = yield getSubscription();
            return (subscription === null || subscription === void 0 ? void 0 : subscription.user) || null;
        });
        this.getPageFromStorage = () => __awaiter(this, void 0, void 0, function* () {
            const { page, pageProps } = yield chrome.storage.local.get([
                "page",
                "pageProps",
            ]);
            if (!page) {
                return {
                    page: this.state.page,
                    pageProps: this.state.pageProps,
                };
            }
            yield chrome.storage.local.remove(["page", "pageProps"]);
            return { page, pageProps };
        });
        this.attachListenerForPageChange = () => {
            const handlePageChange = () => __awaiter(this, void 0, void 0, function* () {
                const { page, pageProps } = yield this.getPageFromStorage();
                this.state = {
                    page,
                    pageProps,
                };
            });
            const handleMessage = (changes) => {
                if ("page" in changes &&
                    "newValue" in changes.page) {
                    handlePageChange();
                }
            };
            chrome.storage.onChanged.addListener(handleMessage);
        };
        const style = document.createElement("style");
        style.textContent = css;
        const body = document.createElement("template");
        body.innerHTML = template;
        const root = this.attachShadow({ mode: "open" });
        root.append(style, body.content);
    }
    connectedCallback() {
        this.attachListenerForPageChange();
        Promise.all([this.getUserFromStorage(), this.getPageFromStorage()]).then(([user, { page, pageProps }]) => {
            this.state = {
                user,
                page,
                pageProps,
            };
        });
    }
    get state() {
        return this._state;
    }
    set state(newState) {
        this._state = Object.assign(Object.assign({}, this._state), newState);
        this.render();
    }
}
AdsSettings.elementName = "ads-settings";
customElements.define(AdsSettings.elementName, AdsSettings);
