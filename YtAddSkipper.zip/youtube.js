'use strict';

function isInIframe() {
    try {
        return window.self !== window.top;
    }
    catch (e) {
        return true;
    }
}
function clickElem(el) {
    const evObj = document.createEvent("Events");
    evObj.initEvent("click", true, false);
    el.dispatchEvent(evObj);
}
function getElementsByClassNames(classNames) {
    return classNames
        .map((name) => Array.from(document.getElementsByClassName(name)) || [])
        .reduce((acc, elems) => acc.concat(elems), [])
        .map((elem) => elem);
}

/******************************************************************************
Copyright (c) Microsoft Corporation.

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
PERFORMANCE OF THIS SOFTWARE.
***************************************************************************** */

function __awaiter(thisArg, _arguments, P, generator) {
  function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
  return new (P || (P = Promise))(function (resolve, reject) {
      function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
      function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
      function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
      step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
}

function __classPrivateFieldGet(receiver, state, kind, f) {
  if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a getter");
  if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return kind === "m" ? f : kind === "a" ? f.call(receiver) : f ? f.value : state.get(receiver);
}

function __classPrivateFieldSet(receiver, state, value, kind, f) {
  if (kind === "m") throw new TypeError("Private method is not writable");
  if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a setter");
  if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return (kind === "a" ? f.call(receiver, value) : f ? f.value = value : state.set(receiver, value)), value;
}

typeof SuppressedError === "function" ? SuppressedError : function (error, suppressed, message) {
  var e = new Error(message);
  return e.name = "SuppressedError", e.error = error, e.suppressed = suppressed, e;
};

function mainLoop(cb, ms) {
    const call = () => {
        cb().finally(() => {
            setTimeout(() => call(), ms);
        });
    };
    call();
}

function debug(...args) {
    return void 0;
}
function error(...args) {
    return console.error("[yt-ad-skipper:error]", ...args);
}
function warn(...args) {
    return console.warn("[yt-ad-skipper:warn]", ...args);
}
const logger = { debug, error, warn };

const AD_PLAYBACK_OFFSET = 5;
const DEFAULT_CONFIG = Object.freeze({
    globalConfig: {
        timeToSkip: AD_PLAYBACK_OFFSET,
        muteAd: false,
    },
    channelConfigs: {},
});
function getSubscription() {
    return __awaiter(this, void 0, void 0, function* () {
        const { subscription } = yield chrome.storage.local.get(["subscription"]);
        return subscription;
    });
}
function getConfig() {
    return __awaiter(this, void 0, void 0, function* () {
        const { config, subscription } = yield chrome.storage.local.get([
            "config",
            "subscription",
        ]);
        if (!config || !(subscription === null || subscription === void 0 ? void 0 : subscription.subscriptionId)) {
            return DEFAULT_CONFIG;
        }
        return config;
    });
}
function getTimeToSkipAdOffset(channelId) {
    return __awaiter(this, void 0, void 0, function* () {
        const config = yield getConfig();
        if (channelId && channelId in config.channelConfigs) {
            return config.channelConfigs[channelId].timeToSkip;
        }
        return config.globalConfig.timeToSkip;
    });
}
function getShouldMuteAd(channelId) {
    return __awaiter(this, void 0, void 0, function* () {
        const config = yield getConfig();
        if (channelId && channelId in config.channelConfigs) {
            return config.channelConfigs[channelId].muteAd;
        }
        return config.globalConfig.muteAd;
    });
}
function getIsSkipSkippingEnabled() {
    return __awaiter(this, void 0, void 0, function* () {
        const subscription = yield getSubscription();
        return !!(subscription === null || subscription === void 0 ? void 0 : subscription.user);
    });
}

function addMilliseconds(date, offset) {
    const clonedDate = new Date();
    clonedDate.setTime(date.getTime() + offset);
    return clonedDate;
}

var Events;
(function (Events) {
    Events["tick"] = "tick";
    Events["adPlayStarted"] = "adPlayStarted";
    Events["adChanged"] = "adChanged";
    Events["adPlayEnded"] = "adPlayEnded";
    Events["locationChanged"] = "locationChanged";
})(Events || (Events = {}));
const EventNames = Object.keys(Events);
const callbacks = EventNames.reduce((acc, evt) => (Object.assign(Object.assign({}, acc), { [evt]: [] })), {});
let currentAd;
let currentLoc = document.location.href;
mainLoop(() => __awaiter(void 0, void 0, void 0, function* () {
    var _a, _b;
    const nextLoc = document.location.href;
    const adPlaying = (_b = (_a = document
        .querySelector(".ytp-ad-visit-advertiser-button")) === null || _a === void 0 ? void 0 : _a.getAttribute("aria-label")) !== null && _b !== void 0 ? _b : undefined;
    const eventsToCall = [];
    const cbArg = [
        { ad: currentAd, location: currentLoc },
        { ad: adPlaying, location: nextLoc },
    ];
    if (currentLoc !== nextLoc) {
        eventsToCall.push(Events.locationChanged);
        currentLoc = nextLoc;
    }
    if (currentAd !== adPlaying) {
        if (adPlaying) {
            eventsToCall.push(Events.adPlayStarted);
        }
        if (currentAd && adPlaying) {
            eventsToCall.push(Events.adChanged);
        }
        if (currentAd && !adPlaying) {
            eventsToCall.push(Events.adPlayEnded);
        }
        currentAd = adPlaying;
    }
    eventsToCall.push(Events.tick);
    eventsToCall.forEach((evt) => {
        callbacks[evt].forEach((cb) => {
            cb(cbArg[0], cbArg[1]);
        });
    });
}), 200);
const YouTubeEvents = {
    addListener: (event, cb) => {
        if (!EventNames.includes(event)) {
            return;
        }
        callbacks[event].push(cb);
    },
};

function isVideoMuted() {
    const volumeSlider = document.querySelector(".ytp-volume-slider-handle");
    return parseInt((volumeSlider === null || volumeSlider === void 0 ? void 0 : volumeSlider.style.left) || "0") === 0;
}
function clickSkipAdBtn() {
    const elems = getElementsByClassNames([
        "videoAdUiSkipButton",
        "ytp-ad-skip-button ytp-button",
        "ytp-ad-skip-button-modern ytp-button",
    ]);
    elems.forEach((el) => clickElem(el));
}
function clickMuteBtn() {
    const muteBtn = document.querySelector(".ytp-mute-button");
    if (!muteBtn) {
        return;
    }
    clickElem(muteBtn);
}
function getChannelInfo() {
    var _a;
    const channelA = document.querySelector("ytd-video-owner-renderer ytd-channel-name a");
    if (!channelA) {
        return {
            channelId: "",
            channelName: "",
            imageUrl: "",
        };
    }
    const channelName = channelA.innerText;
    const channelId = channelA.href.split("/").pop() || "";
    const imageUrl = ((_a = document.querySelector("ytd-video-owner-renderer img")) === null || _a === void 0 ? void 0 : _a.src) || "";
    return {
        imageUrl,
        channelId,
        channelName,
    };
}
function isVideoPage() {
    return document.location.pathname === "/watch";
}

var _VideoAdSkipper_skipAt, _VideoAdSkipper_enableSkipSkipping;
class VideoAdSkipper {
    constructor() {
        _VideoAdSkipper_skipAt.set(this, null);
        _VideoAdSkipper_enableSkipSkipping.set(this, false);
    }
    setupListeners() {
        YouTubeEvents.addListener(Events.adPlayStarted, () => this.scheduleClick());
        YouTubeEvents.addListener(Events.adPlayEnded, () => this.teardown());
        YouTubeEvents.addListener(Events.tick, () => this.tick());
    }
    teardown() {
        __classPrivateFieldSet(this, _VideoAdSkipper_skipAt, null, "f");
    }
    skipSurveyImmediately() {
        clickSkipAdBtn();
    }
    scheduleClick() {
        return __awaiter(this, void 0, void 0, function* () {
            const { channelId } = getChannelInfo();
            const skipAdTime = yield getTimeToSkipAdOffset(channelId);
            __classPrivateFieldSet(this, _VideoAdSkipper_enableSkipSkipping, yield getIsSkipSkippingEnabled(), "f");
            if (skipAdTime < 0) {
                this.teardown();
                return;
            }
            __classPrivateFieldSet(this, _VideoAdSkipper_skipAt, addMilliseconds(new Date(), skipAdTime * 1000), "f");
            logger.debug("scheduling skip at ", __classPrivateFieldGet(this, _VideoAdSkipper_skipAt, "f"));
            this.renderCountdown();
        });
    }
    renderCountdown() {
        var _a;
        const countdown = document.querySelector("#yas_countdown");
        const text = countdown === null || countdown === void 0 ? void 0 : countdown.querySelector("span");
        if (!__classPrivateFieldGet(this, _VideoAdSkipper_skipAt, "f")) {
            countdown === null || countdown === void 0 ? void 0 : countdown.remove();
            return;
        }
        const time = Math.floor(Math.max(0, (__classPrivateFieldGet(this, _VideoAdSkipper_skipAt, "f").getTime() - new Date().getTime()) / 1000));
        const newText = document.createElement("span");
        newText.textContent = `Ad will be skipped in ${time} seconds. `;
        if (countdown) {
            text === null || text === void 0 ? void 0 : text.replaceWith(newText);
            return;
        }
        const newCountdown = document.createElement("div");
        newCountdown.id = "yas_countdown";
        newCountdown.style.margin = "10px 0";
        newCountdown.style.color = "var(--yt-spec-text-primary)";
        const link = document.createElement("a");
        link.href = "#";
        link.style.color = "inherit";
        link.style.textDecoration = "none";
        link.style.borderBottom = "1px solid";
        link.textContent = `Click here to not skip this ad. ${__classPrivateFieldGet(this, _VideoAdSkipper_enableSkipSkipping, "f") ? "" : "🔒"}`;
        link.onclick = () => {
            if (__classPrivateFieldGet(this, _VideoAdSkipper_enableSkipSkipping, "f")) {
                this.teardown();
            }
            return false;
        };
        if (!__classPrivateFieldGet(this, _VideoAdSkipper_enableSkipSkipping, "f")) {
            newCountdown.title =
                "This feature is locked. Please go to extension settings to enable it.";
        }
        newCountdown.append(newText, link);
        (_a = document
            .querySelector("ytd-video-primary-info-renderer #container")) === null || _a === void 0 ? void 0 : _a.insertAdjacentElement("afterbegin", newCountdown);
    }
    tick() {
        this.renderCountdown();
        if (!__classPrivateFieldGet(this, _VideoAdSkipper_skipAt, "f")) {
            return;
        }
        if (__classPrivateFieldGet(this, _VideoAdSkipper_skipAt, "f") <= new Date()) {
            clickSkipAdBtn();
            this.teardown();
        }
    }
}
_VideoAdSkipper_skipAt = new WeakMap(), _VideoAdSkipper_enableSkipSkipping = new WeakMap();

class AdMuter {
    setupListeners() {
        YouTubeEvents.addListener(Events.adPlayStarted, () => this.handleAdPlaybackStart());
        YouTubeEvents.addListener(Events.adPlayEnded, () => this.resetSound());
    }
    handleAdPlaybackStart() {
        return __awaiter(this, void 0, void 0, function* () {
            if (isVideoMuted()) {
                return;
            }
            const { channelId } = getChannelInfo();
            if (yield getShouldMuteAd(channelId)) {
                clickMuteBtn();
            }
        });
    }
    resetSound() {
        if (isVideoMuted()) {
            clickMuteBtn();
        }
    }
}

const CONFIGURE_CHANNEL = "CONFIGURE_CHANNEL";
const VERIFY_SUBSCRIPTION = "VERIFY_SUBSCRIPTION";

class ConfigureChannelBtn {
    constructor() {
        this.tryAgain = false;
    }
    setupListeners() {
        YouTubeEvents.addListener(Events.locationChanged, (_, { location }) => {
            this.handleLocation();
        });
        YouTubeEvents.addListener(Events.tick, () => {
            if (!this.hasButton()) {
                this.tryAgain = false;
                this.createButton();
            }
        });
        this.createButton();
    }
    handleLocation() {
        if (!isVideoPage()) {
            return;
        }
        this.createButton();
    }
    hasButton() {
        return !!document.querySelector("#yas_config_channel_btn");
    }
    createButton() {
        if (this.hasButton()) {
            return;
        }
        const related = document.querySelector("#related");
        if (!related) {
            return;
        }
        const div = document.createElement("div");
        div.style.display = "flex";
        div.style.alignItems = "center";
        div.style.justifyContent = "center";
        const btn = document.createElement("a");
        btn.id = "yas_config_channel_btn";
        btn.title = "Configure ad skipping for this channel";
        btn.innerHTML = `Configure Ads for this channel`;
        btn.style.lineHeight = "1.5em";
        btn.style.cursor = "pointer";
        btn.style.fontSize = "1.2em";
        btn.style.color = "var(--yt-spec-text-primary, black)";
        btn.style.borderBottom = "1px solid var(--yt-spec-text-primary, black)";
        btn.style.marginBottom = "1em";
        btn.onclick = () => {
            const { channelId, channelName, imageUrl } = getChannelInfo();
            chrome.runtime.sendMessage({
                type: CONFIGURE_CHANNEL,
                channel: {
                    channelId,
                    channelName,
                    imageUrl,
                },
            });
        };
        div.append(btn);
        related.insertAdjacentElement("beforebegin", div);
    }
}

class BannerAdRemover {
    setupListeners() {
        YouTubeEvents.addListener(Events.tick, () => {
            getElementsByClassNames([
                "ytp-ad-overlay-close-button",
            ]).forEach((elem) => clickElem(elem));
        });
    }
}

function main() {
    if (isInIframe()) {
        return;
    }
    chrome.runtime.sendMessage({
        type: VERIFY_SUBSCRIPTION,
    });
    new VideoAdSkipper().setupListeners();
    new AdMuter().setupListeners();
    new ConfigureChannelBtn().setupListeners();
    new BannerAdRemover().setupListeners();
}
main();
